package com.wlv.chatblog;

import android.app.Application;



public class ApplicationTest  {

}